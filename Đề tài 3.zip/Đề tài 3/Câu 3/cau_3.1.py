# tổng cộng có bao nhiêu hành khách trên chuyến tàu?
from pyspark import SparkContext
sc = SparkContext('local','quzkhanh')

rdd = sc.textFile('/home/quzkhanh/Code/BigData/Đề tài 3/Spark_Titanic.csv')
header = rdd.first()
data = rdd.filter(lambda x: x != header)
# Tách mỗi dòng thành mảng bằng dấu phẩy (xử lý CSV cơ bản)
rows = data.map(lambda line: line.split(','))

count = data.count()

print(f"Số Hành Khách Tham Gia: {count}")

